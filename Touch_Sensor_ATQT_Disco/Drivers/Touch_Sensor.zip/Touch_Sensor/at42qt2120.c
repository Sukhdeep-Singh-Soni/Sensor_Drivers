/*
 * at42qt2120.c
 *
 *  Created on: Oct 11, 2022
 *      Author: Sukhdeep
 *      Please include below instructions in main.c
 *     - touchSensor_Init()
 *     - HAL_TIM_Base_Start(&htim2); //1ms timer for delay
 	   - HAL_TIM_Base_Start_IT(&htim5); //20ms timer for checking touch press and release and logic implementation.
 */
#include "at42qt2120.h"
#include "tim.h"

uint8_t slider_previousVal=0, slider_previousVal1=0, touch_detect, touch_status, hold_status;
uint8_t tap_speed=0, tap_detect=0, tap_prev_tick=0, tap_next_tick=0, tap_status;
uint16_t hld_count=0, prev_hld=0, new_hld=0;
uint8_t cid=0, i=1, lflag=0, count=0;
uint8_t int_bit=0, prev_tick=0, new_tick=0;
uint8_t   hold_detect=0;
int slider_newVal=0, slider_detected=0, slider_ret_val=0;
uint8_t Sleep_wkup =0;
uint8_t press=0,release=0;
char Print_out[40]={0};

uint8_t check_cid(void)
{
	uint8_t reg = 0x00;
	uint8_t ret=0;
	uint8_t data=0;
	while(HAL_I2C_GetState(I2C_HANDLE)!= HAL_I2C_STATE_READY);
	ret = HAL_I2C_Master_Transmit(I2C_HANDLE, DEV_ADDR, &reg, 1, HAL_MAX_DELAY);
	if(ret!=HAL_OK){

		Error_Handler();
	}
	while(HAL_I2C_GetState(I2C_HANDLE)!= HAL_I2C_STATE_READY);
	ret = HAL_I2C_Master_Receive(I2C_HANDLE, DEV_ADDR, &data, 1, HAL_MAX_DELAY);
	if(ret!=HAL_OK){

		Error_Handler();
	}

	if(data != CID)
		return 0;
	else
		return data;
}

uint8_t read8_i2c(uint8_t reg)
{
		uint8_t ret=0;
		uint8_t data=0;
		while(HAL_I2C_GetState(I2C_HANDLE)!= HAL_I2C_STATE_READY);
		ret = HAL_I2C_Master_Transmit(I2C_HANDLE, DEV_ADDR, &reg, 1, HAL_MAX_DELAY);
		if(ret!=HAL_OK){

			Error_Handler();
		}
		while(HAL_I2C_GetState(I2C_HANDLE)!= HAL_I2C_STATE_READY);
		ret = HAL_I2C_Master_Receive(I2C_HANDLE, DEV_ADDR, &data, 1, HAL_MAX_DELAY);
		if(ret!=HAL_OK){

			Error_Handler();
		}

		return data;
}

uint16_t read16_i2c(uint8_t reg)
{
		uint8_t ret=0;
		uint8_t val[2]={0};
		uint16_t data=0;
		while(HAL_I2C_GetState(I2C_HANDLE)!= HAL_I2C_STATE_READY);
		ret = HAL_I2C_Master_Transmit(I2C_HANDLE, DEV_ADDR, &reg, 1, HAL_MAX_DELAY);
		if(ret!=HAL_OK){

			Error_Handler();
		}
		while(HAL_I2C_GetState(I2C_HANDLE)!= HAL_I2C_STATE_READY);
		ret = HAL_I2C_Master_Receive(I2C_HANDLE, DEV_ADDR, val, 2, HAL_MAX_DELAY);
		if(ret!=HAL_OK){

			Error_Handler();
		}

		data = val[1]<<8;
		data = data | val[0];

		return data;
}

uint8_t write8_i2c(uint8_t reg, uint8_t value)
{
		uint8_t ret=0;
		uint8_t val[2]={0};
		val[0]=reg;
		val[1]=value;
		while(HAL_I2C_GetState(I2C_HANDLE)!= HAL_I2C_STATE_READY);
		ret = HAL_I2C_Master_Transmit(I2C_HANDLE, DEV_ADDR, val, 2, HAL_MAX_DELAY);
		if(ret!=HAL_OK){

			Error_Handler();
		}

		return 0;
}

void enable_slider(void)
{
	write8_i2c(SLIDER_OPTIONS_REG, 0x80);
}

uint8_t key_detect(void)
{
	uint8_t detectStatus = read8_i2c(DETECTION_STATUS_REG);
	if(is_bitSet(detectStatus,0))
		return 1;
	else
		return 0;
}

uint8_t is_keyPressed(uint8_t index)
{
	if(index > 11)
		return 0;
	uint8_t address = 3;
	if(index > 7)
	{
		address = 4;
		index -= 8;
	}
	uint8_t keyStatus = read8_i2c(address);
	if(is_bitSet(keyStatus, index))
		return 1;
	else
		return 0;
}

uint8_t is_bitSet(uint8_t byte, uint8_t pos)
{
	if(byte & (1 << pos))
		return 1;
	else
		return 0;
}

uint8_t key_val(uint8_t key_no)
{
	if(key_detect())
	{
		if(is_keyPressed(key_no))
			return 1;
		else
			return 0;
	}
	return 0;

}

uint8_t sliderPosition(void)
{
	uint8_t position = read8_i2c(SLIDER_POSITION_REG);
	return position;
}

uint8_t slider_detect(void)
{
	uint8_t detectStatus = read8_i2c(DETECTION_STATUS_REG);
		if(is_bitSet(detectStatus,1))
			return 1;
		else
			return 0;
}

uint8_t slider_val(void)
{
	if(slider_detect())
	{
		return sliderPosition();
	}
	return 255;
}

void set_detectIntegrator(uint8_t value)
{
	if(value <= 0) value = 1;
	if(value > 32) value = 32;

	write8_i2c(DI_REG, value);
}

void set_keyThreshold(uint8_t index, uint8_t threshold)
{
	if(index > 11) return;
	uint8_t address = KEY0_DETECT_THRESHOLD_REG + index;
	write8_i2c(address, threshold);
}

void set_timeRecalDelay(uint8_t delay)
{
	write8_i2c(TRD_REG, delay);
}

void set_TTD(uint8_t value)
{
	write8_i2c(TTD_REG, value);
}

void set_ATD(uint8_t value)
{
	write8_i2c(ATD_REG, value);
}

void enable_wheel(void)
{
	write8_i2c(SLIDER_OPTIONS_REG, 0xC0);
}

uint8_t get_TTD(void)
{
	uint8_t data = read8_i2c(TTD_REG);
	return data;
}

uint8_t get_ATD(void)
{
	uint8_t data = read8_i2c(ATD_REG);
	return data;
}

uint8_t get_ketThreshold(uint8_t index)
{
	if(index > 11) return 0;
	uint8_t address = KEY0_DETECT_THRESHOLD_REG + index;
	uint8_t data = read8_i2c(address);
	return data;
}

uint8_t get_detectIntegrator(void)
{
	uint8_t data = read8_i2c(DI_REG);
	return data;
}

void set_DHT(uint8_t time)
{
	write8_i2c(DHT_REG, time);
}

void touchSensor_Init(void)
{
	  //check chip id
	  cid=check_cid();

	  //enable slider
	  enable_slider();

	  //set key 0,1,2 threshold values
	  set_keyThreshold(0, KEYS_THRESHOLD);
	  set_keyThreshold(1, KEYS_THRESHOLD);
	  set_keyThreshold(2, KEYS_THRESHOLD);

	  //set no. of samples before a valid key detect
	  set_detectIntegrator(3);

	  //set re-caliberation time
	  set_timeRecalDelay(30);

	  //set drift hold time, touch towards drift and touch away from drift
	  set_DHT(25);
	  set_TTD(6);
	  set_ATD(5);
}

void touchSensor_Process(void)
{

	//new_tick = 0;
	tap_detect = 0;
	//hold_detect = 0;
	slider_detected = 0;
	/*if(i == 4)
	{
		i = 1;
		//__HAL_TIM_SET_COUNTER(&htim2,0);
	}*/
	//__HAL_TIM_SET_COUNTER(&htim2,0);
	//prev_tick = __HAL_TIM_GET_COUNTER(&htim2);
	//int_bit = 1;

	 /*------------------------------SLIDER DIRECTION DETECTION------------------------------*/
		touch_status = mvp_touch_forward_backward_tap_detect();

	 /*------------------------------SINGLE TAP DETECTION------------------------------------*/
			//mvp_touch_single_tap_detect();

			/*	  hld_count++;
				  if(hld_count == 3)
					  new_tick = __HAL_TIM_GET_COUNTER(&htim2) - prev_tick;

				  if((new_tick) >= 1 && (new_tick) <= 5000) //1ms timer 1s-1.6s
				  		  {
				  			  hold_detect = 1;
				  		  }*/
/*
				  if(i++ <= 3)
				  {
				  tap_next_tick += __HAL_TIM_GET_COUNTER(&htim2);

				  }
				  if(i == 3)
				  {
					  if((tap_next_tick - tap_prev_tick) > 50 && (tap_next_tick - tap_prev_tick) < 200)
					  {
				  			hold_detect = 1;
					  }
				  }
				  tap_prev_tick = tap_next_tick;
				  tap_detect = 1;*/
			 /* hld_count++;
			  finger_press_detect(&prev_hld);
			  prev_tick = HAL_GetTick();
			  finger_leave_detect(&new_hld);
			  if((HAL_GetTick() - prev_tick) >= 30000000)
				  printf("\t\tHOLD Detected\r\n");*/
		  //}

		  /*-----------------------------HOLD DETECTION------------------------------------------*/

		  //compare hold count value to some hard coded value
		/*  if(hld_count > 3 && slider_detected != 1 && hold_detect == 1)
		  {
			  printf("\t\tHOLD Detected\r\n");
			  hld_count = 0;
			  hold_detect = 0;
			  //This variable is used for putting microcontroller to sleep and wake it up also.
			  //int_bit = 1;
		  }*/

		  printf("Slider: %d\r\n", sliderPosition());
		 // HAL_Delay(100);
		  delay_us(100U);
		  //osDelay(100);
}

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
	if(GPIO_Pin == INT_Pin)
	{

		 // printf("inside interrupt\r\n");
		  //mvp_touch_hold_detect();
	/*	 new_hld = hld_count - prev_hld;
		 if(new_hld > 120 && new_hld < 250 && slider_detected != 1)
				printf("\t\tHold Detected\r\n");
		 prev_hld = new_hld;
		printf("inside interrupt\r\n");*/
		 // touchSensor_Process();

		//printf("HOLD value is %d", hld_count);
		/*if(slider_detected != 1 && tap_detect == 1)
		{
			hld_count++;
			if(hld_count == 3)
			{
			printf("\t\tHOLD value is %d\r\n", hld_count);
			hld_count = 0;
			}
		}*/

	}
}
/*void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
	if(GPIO_Pin == Touch_INT_Pin)
	{
		if(Sleep_wkup == 1){
			printf("Entering into sleep\r\n");
			sprintf(Print_out,"Entering into sleep ....\r\n");
			HAL_UART_Transmit(&huart3, (uint8_t*)Print_out, sizeof(Print_out), HAL_MAX_DELAY);
		}
		else if(Sleep_wkup == 2){
			printf("Waking up the system\r\n");
			sprintf(Print_out,"Waking up the system ....\r\n");
			HAL_UART_Transmit(&huart3, (uint8_t*)Print_out, sizeof(Print_out), HAL_MAX_DELAY);
		}
	}
}*/

//@brief This function is used to print values on uart using printf
//extern "C" {
int __io_putchar(uint8_t ch){

	HAL_UART_Transmit(&huart1, &ch, sizeof(ch), HAL_MAX_DELAY);

	return ch;
}

//}

void finger_press_detect(uint8_t* prev_value)
{
	 while(1)
	  {
		 *prev_value = sliderPosition();
		 delay_us(30U);
		 //osDelay(50);
		  if(*prev_value != sliderPosition())
			  break;
	  }
}

void finger_leave_detect(uint8_t* prev_value)
{
	 while(1)
	  {
		 *prev_value = sliderPosition();
		  delay_us(70U);
		 //osDelay(50);
		  if(*prev_value == sliderPosition())
		  {
			break;
		  }
	  }
}

void delay_us (uint16_t us)
	  {

	  	__HAL_TIM_SET_COUNTER(&htim2,0);  // set the counter value a 0
	  	while (__HAL_TIM_GET_COUNTER(&htim2) < us);  // wait for the counter to reach the us input in the parameter
	  }

/*uint8_t int_detect(uint16_t gpio_pin)
{
	if(gpio_pin == QINT_Pin)
	{
		if(HAL_GPIO_ReadPin(QINT_GPIO_Port, QINT_Pin) == 0)
			int_bit = 1;
	}
	return int_bit;
}*/

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim) //20ms timer 5(gives interrupt)
{
  /* USER CODE BEGIN Callback 0 */

  /* USER CODE END Callback 0 */
 /* if (htim->Instance == TIM11) {
    HAL_IncTick();
  }*/
  /* USER CODE BEGIN Callback 1 */
	if(htim->Instance == TIM5)
	{
		hld_count++;
		//slider_previousVal = sliderPosition();
		//delay_us(30U);	//1ms timer 2 used for providinig delay only (not giving interrupt)
		 /* if(slider_previousVal != sliderPosition())
		  {*/
			/*  if(HAL_GPIO_ReadPin(INT_GPIO_Port, INT_Pin) == 0)
			  {
				  count++;
				  if(count == 1)
				  {
				  slider_previousVal = sliderPosition();
				  }
				  //delay_us(100);
			  }
			  else if(HAL_GPIO_ReadPin(INT_GPIO_Port, INT_Pin) == 1)
			  {
				  slider_previousVal1 = sliderPosition();
				  touchSensor_Process();
				  count = 0;
			  }*/

		if(key_detect())
		{
			  press++;
			  if(press == 1)
			  {
			  slider_previousVal = sliderPosition();
			  }
			  release = 0;
		}
		else
		{
			release++;
			if(release == 1)
			{
			slider_previousVal1 = sliderPosition();
		    touchSensor_Process();
		    if(press > 50 && press < 250)
		    {
		    	printf("\t\tHold Detected\r\n");
		    }
			}
				press = 0;
		}
		// __HAL_TIM_SET_COUNTER(&htim2,0);
			 // prev_tick = __HAL_TIM_GET_COUNTER(&htim2);
			  touch_detect = TAP;

		  //}
		  //else
			//  touch_detect = NO_TOUCH;
	}
  /* USER CODE END Callback 1 */
}

int8_t mvp_touch_forward_backward_tap_detect(void)
{
	/* if(slider_previousVal != sliderPosition())
			  {
				delay_us(200);
				if(slider_previousVal != sliderPosition())
				{
					delay_us(200);
					if(slider_previousVal != sliderPosition())
					{
						printf("\t\tHold Detected\r\n");
						return HOLD;
					}
				 }
			  }*/
		  //finger touch press detection
		  //finger_press_detect(&slider_previousVal);

		  //save previous value
		 // slider_previousVal = sliderPosition();

		  //wait until user leaves the finger
		 // finger_leave_detect(&slider_previousVal1);

		  //compare that position with previous value
		  slider_newVal = slider_previousVal1 - slider_previousVal;

		  //print direction of slide
		  if(slider_newVal > 0 && slider_newVal >= SLIDER_SENSITIVITY){
			  printf("Slider FORWARD Direction\r\n");
			  slider_detected = 1;
			  return SLIDE_FORWARD;
		  }
		  else if(slider_newVal < 0 && slider_newVal <= -SLIDER_SENSITIVITY){
			  printf("Slider BACKWARD Direction\r\n");
			  slider_detected = 1;
			  return SLIDE_BACKWARD;
		  }
		  else if(1)
		  {
			  if(slider_newVal < 0)
				  tap_speed = -slider_newVal;
			  else
				  tap_speed = slider_newVal;
			  if(tap_speed < TAP_SENSITIVITY && tap_speed > 0)
			  {
				  printf("\tTap Detected\r\n");
				  tap_detect = 1;
				  return TAP;
			  }
		  }
		 /* else if(count >= 10)
		  {
			  printf("\t\tHold Detected\r\n");
			  count = 0;
		  }
*/
			  return NO_TOUCH;
}

/*void mvp_touch_single_tap_detect(void)
{


			  //check key detect and print tap detect (and take a count for hold detection)
	  if(slider_newVal < 0)
		  tap_speed = -slider_newVal;
	  else
		  tap_speed = slider_newVal;
	  if(tap_speed < TAP_SENSITIVITY && tap_speed > 0)
	  {
		  printf("\tTap Detected\r\n");
		  tap_detect = 1;
	  }
}*/

void mvp_touch_hold_detect(void)
{
	  	 new_hld = hld_count - prev_hld;
	  		 if(new_hld > 120 && new_hld < 250 && slider_detected != 1)
	  		 {
	  				printf("\t\tHold Detected\r\n");
	  				hold_status = HOLD;
	  		 }
	  		 else
	  			 hold_status = NO_TOUCH;
	  		 prev_hld = new_hld;
	  		printf("inside interrupt\r\n");
}
